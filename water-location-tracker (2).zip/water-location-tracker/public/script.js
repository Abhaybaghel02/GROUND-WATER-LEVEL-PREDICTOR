// Initialize Leaflet map
const map = L.map('map').setView([20.5937, 78.9629], 5);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);

let marker;
let highLayer = L.layerGroup().addTo(map);
let lowLayer = L.layerGroup().addTo(map);

// Utility to draw circles
function drawCircle(lat, lon, color, label, layer) {
  L.circle([lat, lon], {
    radius: 20000,
    color: color,
    fillColor: color,
    fillOpacity: 0.4
  }).bindPopup(label).addTo(layer);
}

// Predict water for a location entered by user
async function predictWater() {
  const location = document.getElementById('locationInput').value;
  if (!location) {
    alert("Please enter a location");
    return;
  }

  const response = await fetch(`/predict?location=${encodeURIComponent(location)}`);
  const data = await response.json();

  document.getElementById('result').innerText =
    `Prediction for "${data.location}": ${data.prediction}`;

  if (marker) map.removeLayer(marker);

  fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${location}`)
    .then(response => response.json())
    .then(locData => {
      if (locData.length > 0) {
        const lat = parseFloat(locData[0].lat);
        const lon = parseFloat(locData[0].lon);
        marker = L.marker([lat, lon]).addTo(map)
          .bindPopup(`Location: ${location}`).openPopup();
        map.setView([lat, lon], 10);
      }
    });
}

// Show HIGH water + RAIN effect
function showHighWater() {
  clearEffects();
  highLayer.clearLayers();
  lowLayer.clearLayers();

  createRainEffect();

  fetch('/grace')
    .then(res => res.json())
    .then(data => {
      data.forEach(d => {
        if (d.wet_anomaly > 0.3) {
          drawCircle(d.lat, d.lon, 'green', `${d.city} (High): ${d.wet_anomaly}`, highLayer);
        }
      });
    });
}

// Show LOW water + LEAVES effect
function showLowWater() {
  clearEffects();
  highLayer.clearLayers();
  lowLayer.clearLayers();

  createLeavesEffect();

  fetch('/grace')
    .then(res => res.json())
    .then(data => {
      data.forEach(d => {
        if (d.wet_anomaly <= 0.3) {
          drawCircle(d.lat, d.lon, 'red', `${d.city} (Low): ${d.wet_anomaly}`, lowLayer);
        }
      });
    });
}

// Create RAIN effect
function createRainEffect() {
  const rainEffect = document.createElement("div");
  rainEffect.classList.add("rain");
  rainEffect.id = "rainEffect";
  document.body.appendChild(rainEffect);

  for (let i = 0; i < 100; i++) {
    const drop = document.createElement("div");
    drop.classList.add("drop");
    drop.style.left = `${Math.random() * 100}vw`;
    drop.style.animationDuration = `${Math.random() * 2 + 1}s`;
    rainEffect.appendChild(drop);
  }
}

// Create LEAVES effect using 3 random images
function createLeavesEffect() {
  const leavesEffect = document.createElement("div");
  leavesEffect.classList.add("leaves");
  leavesEffect.id = "leavesEffect";
  document.body.appendChild(leavesEffect);

  for (let i = 0; i < 30; i++) {
    const leaf = document.createElement("div");
    leaf.classList.add("leaf");

    const leafNumber = Math.floor(Math.random() * 3) + 1; // 1 to 3
    leaf.style.backgroundImage = `url('assets/images/leaf${leafNumber}.png')`;

    leaf.style.left = `${Math.random() * 100}vw`;
    leaf.style.animationDuration = `${3 + Math.random() * 2}s`;
    leaf.style.animationDelay = `${Math.random()}s`;

    leavesEffect.appendChild(leaf);
  }
}

// Clear rain and leaves effects
function clearEffects() {
  const rain = document.getElementById("rainEffect");
  const leaves = document.getElementById("leavesEffect");
  if (rain) rain.remove();
  if (leaves) leaves.remove();
}
// Removed duplicate definition of createLeavesEffect
function showDetails() {
  const location = document.getElementById("location-input").value;
  document.getElementById("display-location").textContent = location || "Unknown";

  // Add your logic for water status & prediction here
  document.getElementById("status").textContent = "Wet";        // example
  document.getElementById("prediction").textContent = "Likely high water presence"; // example
}
