const express = require('express');
const cors = require('cors');
const axios = require('axios');
const fs = require('fs');

const app = express();
const PORT = 3000;

const API_KEY = 'ea616422da225078edcbeb0ea3784e24'; // replace with your actual key

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// 🔮 Water Prediction Route
app.get('/predict', async (req, res) => {
  const location = req.query.location;

  try {
    // Step 1: Get Lat/Lon from Nominatim
    const geo = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: { q: location, format: 'json' }
    });

    if (geo.data.length === 0) {
      return res.status(404).json({ error: "Location not found" });
    }

    const lat = geo.data[0].lat;
    const lon = geo.data[0].lon;

    // Step 2: Fetch Weather
    const weather = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
      params: { lat, lon, appid: API_KEY, units: 'metric' }
    });

    const humidity = weather.data.main.humidity;
    const prediction = humidity > 60 ? "High Water Presence" : "Low Water Presence";

    // Step 3: Log the result
    const log = { location, prediction, humidity, time: new Date().toISOString() };
    fs.appendFileSync('./data/log.json', JSON.stringify(log) + ',\n');

    // Step 4: Send response
    res.json({ location, prediction, humidity });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Prediction failed", details: err.message });
  }
});

// 🛰️ Serve GRACE Data (basic)
app.get('/grace', (req, res) => {
  try {
    const data = fs.readFileSync('./data/grace_data.json', 'utf8');
    res.json(JSON.parse(data));
  } catch (err) {
    res.status(500).json({ error: "Unable to read GRACE data" });
  }
});

// 🛰️ Serve GRACE Data (async style)
app.get('/grace-data', (req, res) => {
  fs.readFile('./data/grace_data.json', 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: "Unable to read GRACE data" });
    res.json(JSON.parse(data));
  });
});

// 🚀 Start Server
app.listen(PORT, () => {
  console.log(`✅ Server is running on http://localhost:${PORT}`);
});
app.get('/grace', (req, res) => {
    const data = fs.readFileSync('./data/grace_data.json', 'utf8');
    res.json(JSON.parse(data));
  });
  